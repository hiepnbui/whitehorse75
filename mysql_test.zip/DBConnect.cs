using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
//Add MySql Library
using MySql.Data.MySqlClient;

namespace ConnectCsharpToMysql
{
    class DBConnect
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;

        //Constructor
        public DBConnect()
        {
            Initialize();
        }

        //Initialize values
        private void Initialize()
        {
            server = "localhost";
            database = "northwind";
            uid = "root";
            password = "Scueo@57";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

            connection = new MySqlConnection(connectionString);
        }


        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //Insert statement
        public void Insert()
        {
            string query = "INSERT INTO employees (ID, Email, FullName, Login) VALUES(55 , 'Narwicka@gmail.com','Green Leaf', '')";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                try
                {
                    //Execute command
                    cmd.ExecuteNonQuery();

                    //close connection
                    this.CloseConnection();
                }
                catch (MySqlException ex)
                {//1062 - Duplicate entry '55' for key 'PRIMARY'
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //Update statement
        public void Update() 
        {
            string query = "UPDATE employees SET FullName='Green Leaf', Login='greenleaf' WHERE FullName='Green Leaf'";

            //Open connection
            if (this.OpenConnection() == true)
            {
                //create mysql command
                MySqlCommand cmd = new MySqlCommand();
                //Assign the query using CommandText
                cmd.CommandText = query;
                //Assign the connection using Connection
                cmd.Connection = connection;

                //Execute query
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }
        }

        //Delete statement
        public void Delete()
        {
            string query = "DELETE FROM employees WHERE FullName='Green Leaf'";

            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                this.CloseConnection();
            }
        }

        //Select statement
    //    public List<string>[] SelectThis(string query)
    //    {
    //        string connStr = "server=localhost;user=root;database=world;port=3306;password=******;";
    //    MySqlConnection conn = new MySqlConnection(connStr);
    //    try
    //    {
    //        Console.WriteLine("Connecting to MySQL...");
    //        conn.Open();

    //        string sql = "SELECT Name, HeadOfState FROM Country WHERE Continent='Oceania'";
    //    MySqlCommand cmd = new MySqlCommand(sql, conn);
    //    MySqlDataReader rdr = cmd.ExecuteReader();

    //        while (rdr.Read())
    //        {
    //            Console.WriteLine(rdr[0]+" -- "+rdr[1]);
    //        }
    //rdr.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        Console.WriteLine(ex.ToString());
    //    }

    //    conn.Close();
    //    Console.WriteLine("Done.");
    //}
    //}

        //Select statement
        public List<string>[] Select(string query)
        {
            //string query = "SELECT * FROM employees";
            int t = query.IndexOf("employees");

            //Create a list to store the result
            List <string>[] list = new List<string>[3];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();

            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                int ncol = dataReader.FieldCount;
                Console.WriteLine(dataReader.RecordsAffected.ToString());
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    //Console.WriteLine(dataReader[0] + " -- " + dataReader[1]);

                    // for (int i=0;i< ncol; i++) 
                    //{
                    //    dataReader.GetName +
                    //   Console.WriteLine(dataReader[i]..ResultSet[i].GetName() + " -- " + dataReader[i]);
                    //}
                    //list[0].Add(dataReader..GetFieldValue<String>(dataReader.GetOrdinal("Field")));
                    if (t > 0)
                    { //from employees
                        list[0].Add(dataReader["ID"] + "");
                    list[1].Add(dataReader["FullName"] + "");
                    list[2].Add(dataReader["Login"] + "");
                }
                    else
                    {//from customers
                        list[0].Add(dataReader["ID"] + "");

                        list[1].Add(dataReader["LastName"].ToString()+ " "+ dataReader["FirstName"].ToString() + "");
                        list[2].Add(dataReader["EmailAddress"] + "");
                    }
                }

                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return list;
            }
            else
            {
                return list;
            }
        }

        //Count statement
        public int Count()
        {
            string query = "SELECT Count(*) FROM employees";
            int Count = -1;

            //Open Connection
            if (this.OpenConnection() == true)
            {
                //Create Mysql Command
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //ExecuteScalar will return one value
                Count = int.Parse(cmd.ExecuteScalar()+"");
                
                //close Connection
                this.CloseConnection();

                return Count;
            }
            else
            {
                return Count;
            }
        }

        //Backup
        public void Backup()
        {
            try
            {
                DateTime Time = DateTime.Now;
                int year = Time.Year;
                int month = Time.Month;
                int day = Time.Day;
                int hour = Time.Hour;
                int minute = Time.Minute;
                int second = Time.Second;
                int millisecond = Time.Millisecond;

                //Save file to current folder with the current date as a filename
                string path;
                path = year + "-" + month + "-" + day + "-" + hour + "-" + minute + "-" + second + "-" + millisecond + ".sql";
                StreamWriter file = new StreamWriter(path);

                
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "mysqldump";
                psi.RedirectStandardInput = false;
                psi.RedirectStandardOutput = true;
                psi.Arguments = string.Format(@"-u{0} -p{1} -h{2} {3}", uid, password, server, database);
                psi.UseShellExecute = false;

                Process process = Process.Start(psi);

                string output;
                output = process.StandardOutput.ReadToEnd();
                file.WriteLine(output);
                process.WaitForExit();
                file.Close();
                process.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Error , unable to backup!");
            }
        }

        //Restore
        public void Restore()
        {
            try
            {
                //Read file from C:\
                string path;
                path = "MySqlBackup.sql";
                StreamReader file = new StreamReader(path);
                string input = file.ReadToEnd();
                file.Close();


                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "mysql";
                psi.RedirectStandardInput = true;
                psi.RedirectStandardOutput = false;
                psi.Arguments = string.Format(@"-u{0} -p{1} -h{2} {3}", uid, password, server, database);
                psi.UseShellExecute = false;

                
                Process process = Process.Start(psi);
                process.StandardInput.WriteLine(input);
                process.StandardInput.Close();
                process.WaitForExit();
                process.Close();
            }
            catch (IOException ex)
            {
                MessageBox.Show("Error , unable to Restore! {0}",ex.ToString());
            }
        }
    }
}
